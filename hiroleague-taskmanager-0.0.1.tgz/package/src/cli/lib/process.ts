import {
  existsSync,
  mkdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  getServerPidFilePath,
  resolveDataDir,
  resolvePort,
  resolveProfileName,
  resolveRuntimeKind,
  type ConfigOverrides,
} from "./config";
import { fetchHealth } from "./api-client";
import { CliError } from "./output";

interface ManagedServerRecord {
  pid: number;
  port: number;
  startedAt: string;
}

export interface ServerStatus {
  pid?: number;
  port?: number;
  running: boolean;
  url?: string;
}

type ServerReadyCallback = (status: ServerStatus) => void | Promise<void>;

function getPidFilePath(overrides: ConfigOverrides = {}): string {
  return getServerPidFilePath(overrides);
}

function readManagedServerRecord(overrides: ConfigOverrides = {}): ManagedServerRecord | null {
  const pidFilePath = getPidFilePath(overrides);
  if (!existsSync(pidFilePath)) return null;

  try {
    const raw = readFileSync(pidFilePath, "utf8");
    return JSON.parse(raw) as ManagedServerRecord;
  } catch {
    return null;
  }
}

function writeManagedServerRecord(
  record: ManagedServerRecord,
  overrides: ConfigOverrides = {},
): void {
  const pidFilePath = getPidFilePath(overrides);
  mkdirSync(path.dirname(pidFilePath), { recursive: true });
  writeFileSync(pidFilePath, JSON.stringify(record, null, 2));
}

function removeManagedServerRecord(overrides: ConfigOverrides = {}): void {
  const pidFilePath = getPidFilePath(overrides);
  if (existsSync(pidFilePath)) rmSync(pidFilePath, { force: true });
}

function isProcessAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

async function waitForHealth(port: number, timeoutMs: number): Promise<boolean> {
  const startedAt = Date.now();

  while (Date.now() - startedAt < timeoutMs) {
    if (await fetchHealth({ port })) return true;
    await Bun.sleep(250);
  }

  return false;
}

function getServerEntryPath(overrides: ConfigOverrides): string {
  const runtime = resolveRuntimeKind(overrides);
  const entrypoint =
    runtime === "dev"
      ? "../../server/bootstrapDev.ts"
      : "../../server/bootstrapInstalled.ts";
  return fileURLToPath(new URL(entrypoint, import.meta.url));
}

function buildServerEnv(overrides: ConfigOverrides): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = {
    ...process.env,
    TASKMANAGER_RUNTIME: resolveRuntimeKind(overrides),
    TASKMANAGER_PROFILE: resolveProfileName(overrides),
    TASKMANAGER_PORT: String(overrides.port),
  };

  // Pass the resolved data directory explicitly so the child process uses the
  // same profile-aware runtime config as the parent command.
  env.TASKMANAGER_DATA_DIR = resolveDataDir(overrides);

  return env;
}

export async function readServerStatus(
  overrides: ConfigOverrides = {},
): Promise<ServerStatus> {
  const port = resolvePort(overrides);
  const healthy = await fetchHealth(overrides);
  const managedRecord = readManagedServerRecord(overrides);

  if (healthy) {
    if (managedRecord && !isProcessAlive(managedRecord.pid)) {
      removeManagedServerRecord(overrides);
      return {
        port,
        running: true,
        url: `http://127.0.0.1:${port}`,
      };
    }

    return {
      pid: managedRecord?.pid,
      port,
      running: true,
      url: `http://127.0.0.1:${port}`,
    };
  }

  if (managedRecord && !isProcessAlive(managedRecord.pid)) {
    removeManagedServerRecord(overrides);
  }

  return { running: false };
}

export async function startServer(
  overrides: ConfigOverrides = {},
  background = false,
  onReady?: ServerReadyCallback,
): Promise<ServerStatus> {
  const port = overrides.port;
  if (!port) {
    throw new CliError("Port is required", 2);
  }

  const currentStatus = await readServerStatus({ ...overrides, port });
  if (currentStatus.running) {
    if (onReady) await onReady(currentStatus);
    return currentStatus;
  }

  const child = Bun.spawn({
    cmd: [process.execPath, getServerEntryPath(overrides)],
    cwd: process.cwd(),
    detached: background,
    env: buildServerEnv({ ...overrides, port }),
    stderr: background ? "ignore" : "inherit",
    stdin: background ? "ignore" : "inherit",
    stdout: background ? "ignore" : "inherit",
  });

  if (background) {
    child.unref();

    const healthy = await waitForHealth(port, 8000);
    if (!healthy) {
      throw new CliError("Server failed to start", 1, {
        hint: "Try running `hirotm start` without --background to inspect logs.",
        url: `http://127.0.0.1:${port}`,
      });
    }

    if (onReady) {
      await onReady({
        pid: child.pid,
        port,
        running: true,
        url: `http://127.0.0.1:${port}`,
      });
    }

    // Persist the pid so later status calls can report a CLI-managed background server.
    writeManagedServerRecord({
      pid: child.pid,
      port,
      startedAt: new Date().toISOString(),
    }, overrides);

    return {
      pid: child.pid,
      port,
      running: true,
      url: `http://127.0.0.1:${port}`,
    };
  }

  // Wait for health before handing control back to the launcher so first-run
  // browser open can happen without hiding the server logs users need.
  const healthy = await waitForHealth(port, 8000);
  if (!healthy) {
    child.kill("SIGTERM");
    throw new CliError("Server failed to start", 1, {
      hint: "Try running `hirotm start` to inspect startup logs directly.",
      url: `http://127.0.0.1:${port}`,
    });
  }

  if (onReady) {
    await onReady({
      pid: child.pid,
      port,
      running: true,
      url: `http://127.0.0.1:${port}`,
    });
  }

  const forwardSignal = (signal: NodeJS.Signals) => {
    child.kill(signal);
  };

  process.on("SIGINT", forwardSignal);
  process.on("SIGTERM", forwardSignal);

  const exitCode = await child.exited;
  process.off("SIGINT", forwardSignal);
  process.off("SIGTERM", forwardSignal);

  if (exitCode !== 0) {
    throw new CliError("Server exited unexpectedly", exitCode || 1);
  }

  return {
    port,
    running: false,
  };
}

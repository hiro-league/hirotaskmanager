import { Command } from "commander";
import type { CliContext } from "../types/context";
import {
  handleServerStart,
  handleServerStatus,
  handleServerStop,
} from "../handlers/server";
import { addClientNameOption, addProfileOption, cliAction } from "../lib/command-helpers";

export function registerServerCommands(
  program: Command,
  ctx: CliContext,
): void {
  const server = program
    .command("server")
    .description("Start, stop, or inspect the local TaskManager server");

  addProfileOption(
    server
      .command("start")
      .description("Start the local TaskManager server")
      .option("-b, --background", "Run the server in the background")
      .option("--data-dir <path>", "Override the task data directory"),
  ).action(
    cliAction((options: {
      background?: boolean;
      dataDir?: string;
    }) => handleServerStart(ctx, options)),
  );

  addProfileOption(
    addClientNameOption(
      server
        .command("status")
        .description("Show whether the local TaskManager server is running"),
    ),
  ).action(cliAction(() => handleServerStatus(ctx)));

  addProfileOption(
    addClientNameOption(
      server
        .command("stop")
        .description(
          "Stop a background server started by hirotm (uses CLI pid file)",
        ),
    ),
  ).action(cliAction(() => handleServerStop(ctx)));
}

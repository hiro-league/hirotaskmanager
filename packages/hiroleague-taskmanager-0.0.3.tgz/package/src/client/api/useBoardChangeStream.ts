import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import type { BoardEvent } from "../../shared/boardEvents";
import { mergeReleaseUpsertIntoList } from "../../shared/boardReleaseMerge";
import type { Board } from "../../shared/models";
import {
  boardDetailQueryKey,
  boardKeys,
  boardTaskDetailKey,
  fetchBoardList,
  fetchBoardTask,
  invalidateBoardStatsQueries,
} from "./queries";
import { devDirectApiOrigin } from "./devDirectApiOrigin";

/** In dev, EventSource must hit the API process directly; Vite's HTTP proxy does not keep Bun SSE subscribers alive. */
function boardEventsUrl(eventBoardId: number): string {
  const path = `/api/events?boardId=${eventBoardId}`;
  if (import.meta.env.PROD) return path;
  const raw = import.meta.env.VITE_API_ORIGIN as string | undefined;
  const fallbackOrigin = devDirectApiOrigin();
  const origin =
    raw && raw.length > 0 ? raw.replace(/\/$/, "") : fallbackOrigin;
  return `${origin}${path}`;
}

/**
 * Listen for server-side board writes so CLI changes invalidate the active board
 * without waiting for focus or a manual refresh.
 */
export function useBoardChangeStream(
  routeBoardId: string | number | null,
  resolvedBoardId: number | null,
): void {
  const qc = useQueryClient();
  const routeKey = boardDetailQueryKey(routeBoardId);
  const eventBoardId =
    typeof routeKey === "number" ? routeKey : resolvedBoardId;

  useEffect(() => {
    if (eventBoardId == null) return;

    const sseUrl = boardEventsUrl(eventBoardId);
    const es = new EventSource(sseUrl, { withCredentials: true });

    const boardCacheKeys: ReadonlyArray<readonly unknown[]> = [
      ...(routeKey != null ? [[...boardKeys.all, routeKey] as const] : []),
      ...(routeKey !== eventBoardId ? [boardKeys.detail(eventBoardId)] : []),
    ];

    const getCurrentBoard = (): Board | undefined => {
      for (const key of boardCacheKeys) {
        const current = qc.getQueryData<Board>(key);
        if (current) return current;
      }
      return undefined;
    };

    const setBoardCaches = (updater: (current: Board) => Board) => {
      for (const key of boardCacheKeys) {
        qc.setQueryData<Board>(key, (current) => (current ? updater(current) : current));
      }
    };

    // Debounce board invalidation so rapid-fire SSE events (e.g. CLI adding
    // 7 lists in a burst) collapse into a single refetch instead of N overlapping ones.
    const INVALIDATE_DEBOUNCE_MS = 300;
    let invalidateTimer: ReturnType<typeof setTimeout> | null = null;

    const invalidateBoardImmediate = () => {
      if (invalidateTimer != null) {
        clearTimeout(invalidateTimer);
        invalidateTimer = null;
      }
      if (routeKey != null) {
        void qc.invalidateQueries({
          queryKey: [...boardKeys.all, routeKey],
          exact: true,
        });
      }
      if (routeKey !== eventBoardId) {
        void qc.invalidateQueries({
          queryKey: boardKeys.detail(eventBoardId),
          exact: true,
        });
      }
      invalidateBoardStatsQueries(qc, eventBoardId);
    };

    const invalidateBoard = () => {
      // Batch rapid invalidations: reset the timer on each call so only the
      // trailing edge fires, producing a single converging refetch.
      if (invalidateTimer != null) clearTimeout(invalidateTimer);
      invalidateTimer = setTimeout(invalidateBoardImmediate, INVALIDATE_DEBOUNCE_MS);
    };

    /** Check whether the cache already reflects this event's board version.
     *  Returns true when the cache `updatedAt` is strictly newer — the granular
     *  merge can be skipped because a later write already landed.  Using `>=`
     *  would drop concurrent writes that share the same millisecond timestamp. */
    const isAlreadyApplied = (event: BoardEvent): boolean => {
      if (event.kind === "board-index-changed") return false;
      const current = getCurrentBoard();
      if (!current) return false;
      return current.updatedAt > event.boardUpdatedAt;
    };

    const onBoardChanged = (raw: Event) => {
      const event = JSON.parse((raw as MessageEvent<string>).data) as BoardEvent;
      if (event.kind !== "board-changed") return;
      // Always schedule convergence — even if the cache timestamp is ahead,
      // the actual entity set may be incomplete due to racing refetches.
      invalidateBoard();
    };

    const onReleaseUpserted = (raw: Event) => {
      const event = JSON.parse((raw as MessageEvent<string>).data) as BoardEvent;
      if (event.kind !== "release-upserted") return;
      if (!isAlreadyApplied(event)) {
        const current = getCurrentBoard();
        if (!current) {
          invalidateBoard();
          return;
        }
        setBoardCaches((b) => ({
          ...b,
          releases: mergeReleaseUpsertIntoList(b.releases, event.release),
          updatedAt: event.boardUpdatedAt,
        }));
      }
      invalidateBoardStatsQueries(qc, event.boardId);
    };

    const onTaskCreatedOrUpdated = async (raw: Event) => {
      const event = JSON.parse((raw as MessageEvent<string>).data) as BoardEvent;
      if (event.kind !== "task-created" && event.kind !== "task-updated") {
        return;
      }
      // Skip the expensive per-entity fetch+merge when the cache is already
      // ahead, but always schedule a convergence refetch — an earlier event's
      // refetch may have raced ahead without including this entity.
      if (isAlreadyApplied(event)) {
        invalidateBoard();
        return;
      }
      try {
        const task = await fetchBoardTask(event.boardId, event.taskId);
        qc.setQueryData(boardTaskDetailKey(event.boardId, event.taskId), task);
        setBoardCaches((current) => {
          const exists = current.tasks.some((item) => item.taskId === task.taskId);
          return {
            ...current,
            tasks: exists
              ? current.tasks.map((item) =>
                  item.taskId === task.taskId ? task : item,
                )
              : [...current.tasks, task],
            updatedAt: event.boardUpdatedAt,
          };
        });
        invalidateBoard();
      } catch {
        invalidateBoard();
      }
    };

    const onTaskRemovedFromLiveBoard = (raw: Event) => {
      const event = JSON.parse((raw as MessageEvent<string>).data) as BoardEvent;
      if (
        event.kind !== "task-deleted" &&
        event.kind !== "task-trashed" &&
        event.kind !== "task-purged"
      ) {
        return;
      }
      if (!isAlreadyApplied(event)) {
        setBoardCaches((current) => ({
          ...current,
          tasks: current.tasks.filter((task) => task.taskId !== event.taskId),
          updatedAt: event.boardUpdatedAt,
        }));
      }
      invalidateBoard();
    };

    const onListCreatedOrUpdated = async (raw: Event) => {
      const event = JSON.parse((raw as MessageEvent<string>).data) as BoardEvent;
      if (event.kind !== "list-created" && event.kind !== "list-updated") {
        return;
      }
      // Skip the per-entity fetch+merge when cache is ahead, but always
      // schedule convergence — a racing refetch from an earlier event may
      // not have included this list yet.
      if (isAlreadyApplied(event)) {
        invalidateBoard();
        return;
      }
      try {
        const list = await fetchBoardList(event.boardId, event.listId);
        setBoardCaches((current) => {
          const exists = current.lists.some((item) => item.listId === list.listId);
          return {
            ...current,
            lists: exists
              ? current.lists.map((item) =>
                  item.listId === list.listId ? list : item,
                )
              : [...current.lists, list],
            updatedAt: event.boardUpdatedAt,
          };
        });
        invalidateBoard();
      } catch {
        invalidateBoard();
      }
    };

    const onListRemovedFromLiveBoard = (raw: Event) => {
      const event = JSON.parse((raw as MessageEvent<string>).data) as BoardEvent;
      if (
        event.kind !== "list-deleted" &&
        event.kind !== "list-trashed" &&
        event.kind !== "list-purged"
      ) {
        return;
      }
      if (!isAlreadyApplied(event)) {
        setBoardCaches((current) => ({
          ...current,
          lists: current.lists.filter((list) => list.listId !== event.listId),
          tasks: current.tasks.filter((task) => task.listId !== event.listId),
          updatedAt: event.boardUpdatedAt,
        }));
      }
      invalidateBoard();
    };

    const onTaskOrListRestored = (raw: Event) => {
      const event = JSON.parse((raw as MessageEvent<string>).data) as BoardEvent;
      if (event.kind !== "task-restored" && event.kind !== "list-restored") {
        return;
      }
      // Restore always needs a full refetch regardless of timestamp.
      invalidateBoard();
    };

    es.addEventListener("board-changed", onBoardChanged);
    es.addEventListener("release-upserted", onReleaseUpserted);
    es.addEventListener("task-created", onTaskCreatedOrUpdated);
    es.addEventListener("task-updated", onTaskCreatedOrUpdated);
    es.addEventListener("task-deleted", onTaskRemovedFromLiveBoard);
    es.addEventListener("task-trashed", onTaskRemovedFromLiveBoard);
    es.addEventListener("task-purged", onTaskRemovedFromLiveBoard);
    es.addEventListener("task-restored", onTaskOrListRestored);
    es.addEventListener("list-created", onListCreatedOrUpdated);
    es.addEventListener("list-updated", onListCreatedOrUpdated);
    es.addEventListener("list-deleted", onListRemovedFromLiveBoard);
    es.addEventListener("list-trashed", onListRemovedFromLiveBoard);
    es.addEventListener("list-purged", onListRemovedFromLiveBoard);
    es.addEventListener("list-restored", onTaskOrListRestored);
    return () => {
      if (invalidateTimer != null) clearTimeout(invalidateTimer);
      es.removeEventListener("board-changed", onBoardChanged);
      es.removeEventListener("release-upserted", onReleaseUpserted);
      es.removeEventListener("task-created", onTaskCreatedOrUpdated);
      es.removeEventListener("task-updated", onTaskCreatedOrUpdated);
      es.removeEventListener("task-deleted", onTaskRemovedFromLiveBoard);
      es.removeEventListener("task-trashed", onTaskRemovedFromLiveBoard);
      es.removeEventListener("task-purged", onTaskRemovedFromLiveBoard);
      es.removeEventListener("task-restored", onTaskOrListRestored);
      es.removeEventListener("list-created", onListCreatedOrUpdated);
      es.removeEventListener("list-updated", onListCreatedOrUpdated);
      es.removeEventListener("list-deleted", onListRemovedFromLiveBoard);
      es.removeEventListener("list-trashed", onListRemovedFromLiveBoard);
      es.removeEventListener("list-purged", onListRemovedFromLiveBoard);
      es.removeEventListener("list-restored", onTaskOrListRestored);
      es.close();
    };
  }, [eventBoardId, qc, routeKey]);
}

/**
 * Phase 6: interactive setup flows for server and client profiles (design §2.8).
 * Initial development: no backward compatibility with pre-role profiles.
 */
import path from "node:path";
import process from "node:process";
import { createInterface } from "node:readline/promises";
import {
  DEFAULT_BIND_ADDRESS,
  ensureRuntimeDirectories,
  hasAnyProfileConfigOnDisk,
  isLoopbackBindAddress,
  resolveAuthDir,
  resolveDefaultProfileName,
  resolveRequireCliApiKey,
} from "../../shared/runtimeConfig";
import { generateCliApiKey } from "../../server/cliApiKeys";
import { INSTALLED_DEFAULT_PORT } from "../../shared/ports";
import { CLI_ERR } from "../types/errors";
import { parsePortOption } from "../lib/core/command-helpers";
import {
  getDefaultInstalledAuthDir,
  getDefaultInstalledDataDir,
  readConfigFile,
  writeConfigFile,
  writeDefaultProfileName,
  type CliConfigFile,
} from "../lib/core/config";
import { canPromptInteractively } from "../lib/core/tty";
import { readServerStatus } from "../lib/core/process";
import { buildLocalServerUrl } from "../../shared/serverStatus";
import { CliError } from "../lib/output/output";
import {
  formatBooleanPrompt,
  formatTextPrompt,
  printInteractiveSetupHeader,
  printSavedProfileSummary,
  spinForMoment,
} from "../lib/output/launcherUi";

export interface LauncherSetupMeta {
  justFinishedInteractiveSetup: boolean;
  firstProfileOnMachine: boolean;
  /** When false, launcher must not start the local Bun server. */
  shouldStartLocalServer: boolean;
}

export interface LauncherSetupResult {
  config: CliConfigFile;
  /** Profile directory name (may differ from argv if the user renamed during the wizard). */
  profileName: string;
  setupMeta: LauncherSetupMeta;
}

function resolveServerProfileDefaults(profile: string): Required<
  Pick<CliConfigFile, "port" | "data_dir" | "auth_dir" | "open_browser" | "role">
> {
  const configScope = { profile, kind: "installed" as const };
  const existing: Partial<CliConfigFile> = readConfigFile(configScope) ?? {};
  return {
    role: "server",
    port: existing.port ?? INSTALLED_DEFAULT_PORT,
    data_dir: path.resolve(
      existing.data_dir ?? getDefaultInstalledDataDir(configScope),
    ),
    auth_dir: path.resolve(
      existing.auth_dir ?? getDefaultInstalledAuthDir(configScope),
    ),
    open_browser: existing.open_browser ?? true,
  };
}

async function promptWithDefault(
  question: string,
  defaultValue: string,
): Promise<string> {
  const rl = createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  try {
    const answer = await rl.question(`${question} `);
    return answer.trim() || defaultValue;
  } finally {
    rl.close();
  }
}

async function promptBoolean(
  question: string,
  defaultValue: boolean,
): Promise<boolean> {
  const rl = createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  try {
    for (;;) {
      const answer = (await rl.question(`${question}: `))
        .trim()
        .toLowerCase();
      if (!answer) return defaultValue;
      if (answer === "y" || answer === "yes") return true;
      if (answer === "n" || answer === "no") return false;
      console.log("Please answer yes or no.");
    }
  } finally {
    rl.close();
  }
}

function isLoopbackUrlHost(hostname: string): boolean {
  const h = hostname.toLowerCase();
  return h === "localhost" || h === "127.0.0.1" || h === "::1";
}

function normalizeClientApiUrl(raw: string): string {
  const trimmed = raw.trim();
  let u: URL;
  try {
    u = new URL(trimmed);
  } catch {
    throw new CliError(
      `Invalid api_url: not a valid URL (${trimmed})`,
      2,
      { code: CLI_ERR.invalidValue, field: "api_url" },
    );
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") {
    throw new CliError(
      "api_url must start with http:// or https://",
      2,
      { code: CLI_ERR.invalidValue, field: "api_url" },
    );
  }
  if (u.protocol === "http:" && !isLoopbackUrlHost(u.hostname)) {
    console.warn(
      "[taskmanager] Warning: http:// with a non-loopback host sends traffic in cleartext; prefer https:// for remote servers.",
    );
  }
  return trimmed.replace(/\/+$/, "");
}

/**
 * Plain `hirotaskmanager` with no profile config: ask server vs client (design §2.8).
 */
export async function chooseSetupModeInteractive(): Promise<"server" | "client"> {
  const rl = createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  try {
    console.log(`How will this machine use TaskManager?
  [s] server  — run the API + database on this machine
  [c] client  — CLI only; connect to a remote server elsewhere`);
    for (;;) {
      const answer = (await rl.question("Choice [s/c]: ")).trim().toLowerCase();
      if (answer === "s" || answer === "server") return "server";
      if (answer === "c" || answer === "client") return "client";
      console.log('Please enter "s" for server or "c" for client.');
    }
  } finally {
    rl.close();
  }
}

export async function runServerSetupWizard(options: {
  profile: string;
  rerun: boolean;
}): Promise<LauncherSetupResult> {
  const machineHadNoProfilesBefore = !hasAnyProfileConfigOnDisk();
  let activeProfile = options.profile;

  if (options.rerun && !canPromptInteractively()) {
    throw new CliError(
      "Re-run setup requires an interactive terminal (TTY).",
      2,
      { code: CLI_ERR.invalidArgs },
    );
  }

  if (options.rerun) {
    const cfg = readConfigFile({
      profile: activeProfile,
      kind: "installed",
    });
    if (!cfg || cfg.role !== "server") {
      throw new CliError(
        `Profile "${activeProfile}" is not a server profile — use --setup-client for client profiles.`,
        2,
        { code: CLI_ERR.invalidArgs, role: cfg?.role },
      );
    }
  }

  if (!canPromptInteractively()) {
    const defaults = resolveServerProfileDefaults(activeProfile);
    const existing: Partial<CliConfigFile> =
      readConfigFile({ profile: activeProfile, kind: "installed" }) ?? {};
    const bind = existing.bind_address ?? DEFAULT_BIND_ADDRESS;
    const config: CliConfigFile = {
      ...defaults,
      ...existing,
      role: "server",
      bind_address: bind,
    };
    if (!isLoopbackBindAddress(bind)) {
      config.require_cli_api_key = true;
    } else if (existing.require_cli_api_key === true) {
      config.require_cli_api_key = true;
    } else {
      delete config.require_cli_api_key;
    }
    writeConfigFile(config, { profile: activeProfile, kind: "installed" });
    ensureRuntimeDirectories({ profile: activeProfile, kind: "installed" });
    return {
      config,
      profileName: activeProfile,
      setupMeta: {
        justFinishedInteractiveSetup: false,
        firstProfileOnMachine: machineHadNoProfilesBefore,
        shouldStartLocalServer: true,
      },
    };
  }

  if (!options.rerun) {
    printInteractiveSetupHeader({
      profileName: activeProfile,
      firstProfileOnMachine: machineHadNoProfilesBefore,
    });
    await spinForMoment(
      "Looking for existing profiles...",
      machineHadNoProfilesBefore
        ? `Creating profile: ${activeProfile}`
        : `Using profile: ${activeProfile}`,
    );
    const nameAns = await promptWithDefault(
      formatTextPrompt("Profile name", activeProfile),
      activeProfile,
    );
    const trimmed = nameAns.trim();
    if (trimmed) activeProfile = trimmed;
  } else {
    printInteractiveSetupHeader({
      profileName: activeProfile,
      firstProfileOnMachine: false,
    });
    await spinForMoment("Loading current server profile...", activeProfile);
  }

  const defaults = resolveServerProfileDefaults(activeProfile);
  const existing: Partial<CliConfigFile> =
    readConfigFile({ profile: activeProfile, kind: "installed" }) ?? {};

  const portValue = await promptWithDefault(
    formatTextPrompt("Pick a port for web/api", String(existing.port ?? defaults.port)),
    String(existing.port ?? defaults.port),
  );

  const dataDirValue = await promptWithDefault(
    formatTextPrompt(
      "Pick a data directory for the database",
      String(existing.data_dir ?? defaults.data_dir),
    ),
    String(existing.data_dir ?? defaults.data_dir),
  );

  const authDirValue = await promptWithDefault(
    formatTextPrompt(
      "Pick an auth directory (passphrase + CLI key storage)",
      String(existing.auth_dir ?? defaults.auth_dir),
    ),
    String(existing.auth_dir ?? defaults.auth_dir),
  );

  const allowRemote = await promptBoolean(
    formatBooleanPrompt(
      "Allow remote access (listen on all interfaces, 0.0.0.0)?",
      !!(existing.bind_address && !isLoopbackBindAddress(existing.bind_address)),
    ),
    !!(existing.bind_address && !isLoopbackBindAddress(existing.bind_address)),
  );

  const bindAddress = allowRemote ? "0.0.0.0" : DEFAULT_BIND_ADDRESS;

  let requireCliApiKey: boolean;
  if (allowRemote) {
    requireCliApiKey = true;
    console.log(
      "Non-loopback bind requires CLI API keys — require_cli_api_key is set to true.",
    );
  } else {
    requireCliApiKey = await promptBoolean(
      formatBooleanPrompt(
        "Require a CLI API key for local connections too?",
        existing.require_cli_api_key === true,
      ),
      existing.require_cli_api_key === true,
    );
  }

  const defaultOpenBrowser =
    process.stdout.isTTY && !process.env.SSH_CONNECTION;
  const openBrowser = await promptBoolean(
    formatBooleanPrompt(
      "Open the default browser when starting the server via hirotaskmanager",
      existing.open_browser ?? defaultOpenBrowser,
    ),
    existing.open_browser ?? defaultOpenBrowser,
  );

  const config: CliConfigFile = {
    ...existing,
    role: "server",
    port: parsePortOption(portValue) ?? defaults.port,
    data_dir: path.resolve(dataDirValue),
    auth_dir: path.resolve(authDirValue),
    open_browser: openBrowser,
    bind_address: bindAddress,
  };
  if (requireCliApiKey) {
    config.require_cli_api_key = true;
  } else {
    delete config.require_cli_api_key;
  }

  writeConfigFile(config, { profile: activeProfile, kind: "installed" });
  ensureRuntimeDirectories({ profile: activeProfile, kind: "installed" });

  await spinForMoment(
    machineHadNoProfilesBefore
      ? `Saving profile: ${activeProfile}`
      : `Updating profile: ${activeProfile}`,
    `Saved ${activeProfile}`,
  );

  const authDirResolved = resolveAuthDir({
    profile: activeProfile,
    kind: "installed",
  });
  const needsKeyByPolicy = resolveRequireCliApiKey({
    profile: activeProfile,
    kind: "installed",
  });

  let nextConfig: CliConfigFile = config;
  if (needsKeyByPolicy) {
    const mint = await promptBoolean(
      formatBooleanPrompt(
        "Mint a first CLI API key now (recommended — server may be unreachable without one)",
        true,
      ),
      true,
    );
    if (mint) {
      const { key } = await generateCliApiKey({
        authDir: authDirResolved,
        label: `setup-${path.basename(activeProfile)}`,
      });
      console.log(
        "\nCopy this key now — it will not be shown again. It is also saved to this profile as api_key.\n",
      );
      process.stdout.write(`${key}\n\n`);
      nextConfig = { ...config, api_key: key };
      writeConfigFile(nextConfig, { profile: activeProfile, kind: "installed" });
    }
  }

  const hasPointer = !!resolveDefaultProfileName();
  const setDefault = await promptBoolean(
    formatBooleanPrompt(
      "Set this profile as the default for hirotm (no --profile needed)",
      !hasPointer,
    ),
    !hasPointer,
  );
  if (setDefault) {
    writeDefaultProfileName(activeProfile);
  }

  const startAfter = await promptBoolean(
    formatBooleanPrompt("Start the server now", true),
    true,
  );

  printSavedProfileSummary({
    created: machineHadNoProfilesBefore,
    profileName: activeProfile,
    appUrl: buildLocalServerUrl(nextConfig.port!),
    dataDir: path.resolve(nextConfig.data_dir!),
    openBrowser,
  });

  return {
    config: nextConfig,
    profileName: activeProfile,
    setupMeta: {
      justFinishedInteractiveSetup: true,
      firstProfileOnMachine: machineHadNoProfilesBefore,
      shouldStartLocalServer: startAfter,
    },
  };
}

export async function runClientSetupWizard(options: {
  profile: string;
  rerun: boolean;
}): Promise<LauncherSetupResult> {
  if (!canPromptInteractively()) {
    throw new CliError(
      "Client setup needs interactive prompts for api_url and api_key. Open a terminal and run: hirotaskmanager --setup-client",
      2,
      { code: CLI_ERR.invalidArgs },
    );
  }

  if (options.rerun) {
    const cfg = readConfigFile({
      profile: options.profile,
      kind: "installed",
    });
    if (!cfg || cfg.role !== "client") {
      throw new CliError(
        `Profile "${options.profile}" is not a client profile — use --setup-server for server profiles.`,
        2,
        { code: CLI_ERR.invalidArgs, role: cfg?.role },
      );
    }
  }

  const machineHadNoProfilesBefore = !hasAnyProfileConfigOnDisk();
  let activeProfile = options.profile;

  printInteractiveSetupHeader({
    profileName: activeProfile,
    firstProfileOnMachine: machineHadNoProfilesBefore,
  });

  if (!options.rerun) {
    const defaultName = activeProfile === "default" ? "remote" : activeProfile;
    const nameAns = await promptWithDefault(
      formatTextPrompt("Profile name", defaultName),
      defaultName,
    );
    const trimmed = nameAns.trim();
    if (trimmed) activeProfile = trimmed;
  }

  const existingClient: Partial<CliConfigFile> =
    readConfigFile({ profile: activeProfile, kind: "installed" }) ?? {};

  const apiUrlRaw = await promptWithDefault(
    formatTextPrompt(
      "Server base URL (api_url)",
      String(existingClient.api_url ?? "https://"),
    ),
    String(existingClient.api_url ?? "https://"),
  );
  const apiUrl = normalizeClientApiUrl(apiUrlRaw);

  const apiKey = await promptWithDefault(
    formatTextPrompt(
      "CLI API key (from the server: hirotaskmanager server api-key generate)",
      String(existingClient.api_key ?? ""),
    ),
    String(existingClient.api_key ?? ""),
  );
  if (!apiKey.trim()) {
    throw new CliError(
      "api_key is required for a client profile.",
      2,
      { code: CLI_ERR.missingRequired, field: "api_key" },
    );
  }

  const config: CliConfigFile = {
    role: "client",
    api_url: apiUrl,
    api_key: apiKey.trim(),
  };

  writeConfigFile(config, { profile: activeProfile, kind: "installed" });

  const hasPointer = !!resolveDefaultProfileName();
  const setDefault = await promptBoolean(
    formatBooleanPrompt(
      "Set this profile as the default for hirotm (no --profile needed)",
      !hasPointer,
    ),
    !hasPointer,
  );
  if (setDefault) {
    writeDefaultProfileName(activeProfile);
  }

  console.log("\nChecking connectivity to the server...\n");
  const status = await readServerStatus({
    kind: "installed",
    profile: activeProfile,
  });
  process.stdout.write(`${JSON.stringify(status)}\n`);

  return {
    config,
    profileName: activeProfile,
    setupMeta: {
      justFinishedInteractiveSetup: true,
      firstProfileOnMachine: machineHadNoProfilesBefore,
      shouldStartLocalServer: false,
    },
  };
}

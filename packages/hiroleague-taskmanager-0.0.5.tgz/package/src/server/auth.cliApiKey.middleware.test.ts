import {
  afterEach,
  beforeAll,
  beforeEach,
  describe,
  expect,
  test,
} from "bun:test";
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { Hono } from "hono";
import {
  authMiddleware,
  resetAuthDiskCacheForTests,
  type AppBindings,
} from "./auth";
import { generateCliApiKey } from "./cliApiKeys";
import { setRuntimeConfigSelection } from "../shared/runtimeConfig";
import { INSTALLED_DEFAULT_PORT } from "../shared/ports";

const PROFILE = "mwtest";
const home = process.env.HOME!;
const profileDir = path.join(home, ".taskmanager", "profiles", PROFILE);
const authDir = path.join(profileDir, "auth");
const dataDir = path.join(profileDir, "data");

let bearerKey: string;

describe("authMiddleware (CLI API key)", () => {
  beforeAll(async () => {
    mkdirSync(authDir, { recursive: true });
    mkdirSync(dataDir, { recursive: true });
    writeFileSync(
      path.join(authDir, "auth.json"),
      `${JSON.stringify(
        {
          version: 1,
          initializedAt: "2020-01-01T00:00:00.000Z",
          passphraseHash: "a".repeat(64),
          recoveryKeyHash: "b".repeat(64),
          activeSessionTokenHash: null,
        },
        null,
        2,
      )}\n`,
      "utf8",
    );
    const { key } = await generateCliApiKey({ authDir, label: "mw" });
    bearerKey = key;
    writeFileSync(
      path.join(profileDir, "config.json"),
      `${JSON.stringify(
        {
          role: "server",
          port: INSTALLED_DEFAULT_PORT,
          data_dir: dataDir,
          auth_dir: authDir,
          bind_address: "127.0.0.1",
          require_cli_api_key: true,
          api_key: key,
        },
        null,
        2,
      )}\n`,
      "utf8",
    );
  });

  beforeEach(() => {
    resetAuthDiskCacheForTests();
    setRuntimeConfigSelection({ profile: PROFILE, kind: "installed" });
  });

  afterEach(() => {
    resetAuthDiskCacheForTests();
    setRuntimeConfigSelection({ profile: "default" });
  });

  test("returns 401 auth_cli_key_required without Bearer on non-exempt /api routes", async () => {
    const app = new Hono<AppBindings>();
    app.use("/api/*", authMiddleware);
    app.get("/api/smoke", (c) => c.json({ ok: true }));

    const res = await app.request("http://localhost/api/smoke", {
      method: "GET",
    });
    expect(res.status).toBe(401);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("auth_cli_key_required");
  });

  test("allows non-exempt /api routes with valid Bearer token", async () => {
    const app = new Hono<AppBindings>();
    app.use("/api/*", authMiddleware);
    app.get("/api/smoke", (c) => c.json({ ok: true }));

    const res = await app.request("http://localhost/api/smoke", {
      method: "GET",
      headers: { Authorization: `Bearer ${bearerKey}` },
    });
    expect(res.status).toBe(200);
  });

  test("returns 401 auth_invalid_cli_key when Bearer does not match stored keys", async () => {
    const app = new Hono<AppBindings>();
    app.use("/api/*", authMiddleware);
    app.get("/api/smoke", (c) => c.json({ ok: true }));

    const res = await app.request("http://localhost/api/smoke", {
      method: "GET",
      headers: {
        Authorization: `Bearer tmk-${"0".repeat(64)}`,
      },
    });
    expect(res.status).toBe(401);
    const body = (await res.json()) as { code?: string };
    expect(body.code).toBe("auth_invalid_cli_key");
  });
});

import { describe, expect, test } from "bun:test";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import {
  generateCliApiKey,
  listCliApiKeyRecords,
  revokeCliApiKeyByPrefix,
  validateCliApiKey,
} from "./cliApiKeys";

describe("cliApiKeys", () => {
  test("generate stores a tmk- key and validates by hash", async () => {
    const authDir = mkdtempSync(path.join(tmpdir(), "tm-clikeys-"));
    const { key, record } = await generateCliApiKey({
      authDir,
      label: "unit",
    });
    expect(key).toMatch(/^tmk-[0-9a-f]{64}$/);
    expect(record.id).toBe(key.slice(0, 8));
    expect(record.label).toBe("unit");
    expect(record.hash.length).toBeGreaterThan(0);
    expect(await validateCliApiKey(authDir, key)).toBe(true);
    expect(await validateCliApiKey(authDir, `${key}x`)).toBe(false);
  });

  test("list and revoke by prefix", async () => {
    const authDir = mkdtempSync(path.join(tmpdir(), "tm-clikeys-"));
    const { key, record } = await generateCliApiKey({ authDir });
    const listed = await listCliApiKeyRecords(authDir);
    expect(listed).toHaveLength(1);
    expect(listed[0]!.id).toBe(record.id);

    const revoked = await revokeCliApiKeyByPrefix(authDir, record.id);
    expect(revoked.id).toBe(record.id);
    expect(await listCliApiKeyRecords(authDir)).toHaveLength(0);
    expect(await validateCliApiKey(authDir, key)).toBe(false);
  });

  test("revoke rejects ambiguous or missing prefix", async () => {
    const authDir = mkdtempSync(path.join(tmpdir(), "tm-clikeys-"));
    await generateCliApiKey({ authDir, label: "a" });
    await generateCliApiKey({ authDir, label: "b" });
    await expect(revokeCliApiKeyByPrefix(authDir, "nope")).rejects.toThrow(
      /No key matches/,
    );
  });
});

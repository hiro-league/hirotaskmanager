import { chmod, mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { constantTimeHexEquals, sha256Hex } from "./cryptoHex";

export const CLI_API_KEYS_FILE_NAME = "cli-api-keys.json";

export interface CliApiKeyRecord {
  id: string;
  hash: string;
  label: string;
  createdAt: string;
}

export interface CliApiKeysFile {
  version: 1;
  keys: CliApiKeyRecord[];
}

function resolveCliApiKeysPath(authDir: string): string {
  return path.join(authDir, CLI_API_KEYS_FILE_NAME);
}

async function applyOwnerOnlyPermissions(targetPath: string): Promise<void> {
  if (process.platform === "win32") return;
  try {
    await chmod(targetPath, 0o600);
  } catch {
    /* best effort */
  }
}

async function ensureAuthDirExists(authDir: string): Promise<void> {
  await mkdir(authDir, { recursive: true });
  if (process.platform === "win32") return;
  try {
    await chmod(authDir, 0o700);
  } catch {
    /* best effort */
  }
}

export async function readCliApiKeysFile(
  authDir: string,
): Promise<CliApiKeysFile | null> {
  const filePath = resolveCliApiKeysPath(authDir);
  try {
    const raw = await readFile(filePath, "utf8");
    const parsed = JSON.parse(raw) as Partial<CliApiKeysFile>;
    if (parsed?.version !== 1 || !Array.isArray(parsed.keys)) {
      throw new Error("Invalid cli-api-keys.json shape");
    }
    return {
      version: 1,
      keys: parsed.keys as CliApiKeyRecord[],
    };
  } catch (e) {
    if ((e as NodeJS.ErrnoException)?.code === "ENOENT") return null;
    throw e;
  }
}

export async function writeCliApiKeysFile(
  authDir: string,
  data: CliApiKeysFile,
): Promise<void> {
  await ensureAuthDirExists(authDir);
  const filePath = resolveCliApiKeysPath(authDir);
  const tmpPath = `${filePath}.tmp`;
  const payload = `${JSON.stringify(data, null, 2)}\n`;
  await writeFile(tmpPath, payload, "utf8");
  await applyOwnerOnlyPermissions(tmpPath);
  await rename(tmpPath, filePath);
  await applyOwnerOnlyPermissions(filePath);
}

export async function hasCliApiKeys(authDir: string): Promise<boolean> {
  const state = await readCliApiKeysFile(authDir);
  return !!state?.keys.length;
}

/**
 * Validates a raw Bearer token against stored SHA-256 hashes (constant-time per entry).
 */
export async function validateCliApiKey(
  authDir: string,
  rawKey: string,
): Promise<boolean> {
  const state = await readCliApiKeysFile(authDir);
  if (!state?.keys.length) return false;
  const digest = sha256Hex(rawKey);
  for (const row of state.keys) {
    if (constantTimeHexEquals(digest, row.hash)) return true;
  }
  return false;
}

function makeKeyString(): string {
  const hex = randomBytes(32).toString("hex");
  return `tmk-${hex}`;
}

export async function generateCliApiKey(options: {
  authDir: string;
  label?: string;
}): Promise<{ key: string; record: CliApiKeyRecord }> {
  const key = makeKeyString();
  const id = key.slice(0, 8);
  const record: CliApiKeyRecord = {
    id,
    hash: sha256Hex(key),
    label: options.label?.trim() ?? "",
    createdAt: new Date().toISOString(),
  };
  const prev = (await readCliApiKeysFile(options.authDir)) ?? {
    version: 1 as const,
    keys: [] as CliApiKeyRecord[],
  };
  const next: CliApiKeysFile = {
    version: 1,
    keys: [...prev.keys, record],
  };
  await writeCliApiKeysFile(options.authDir, next);
  return { key, record };
}

export async function listCliApiKeyRecords(
  authDir: string,
): Promise<CliApiKeyRecord[]> {
  const state = await readCliApiKeysFile(authDir);
  return state?.keys ?? [];
}

export async function revokeCliApiKeyByPrefix(
  authDir: string,
  prefixRaw: string,
): Promise<CliApiKeyRecord> {
  const prefix = prefixRaw.trim().toLowerCase();
  if (prefix.length < 4) {
    throw new Error("Revocation prefix must be at least 4 characters");
  }
  const state = await readCliApiKeysFile(authDir);
  if (!state?.keys.length) {
    throw new Error("No CLI API keys are registered");
  }
  const matches = state.keys.filter(
    (k) =>
      k.id.toLowerCase() === prefix || k.id.toLowerCase().startsWith(prefix),
  );
  if (matches.length === 0) {
    throw new Error(`No key matches prefix "${prefixRaw.trim()}"`);
  }
  if (matches.length > 1) {
    throw new Error(
      `Prefix "${prefixRaw.trim()}" is ambiguous (${matches.length} matches); use a longer prefix`,
    );
  }
  const revoked = matches[0]!;
  const nextKeys = state.keys.filter((k) => k.id !== revoked.id);
  await writeCliApiKeysFile(authDir, { version: 1, keys: nextKeys });
  return revoked;
}

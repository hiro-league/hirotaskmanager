import {
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { CLI_ERR, CliError } from "../cli/types/errors";
import { DEV_DEFAULT_PORT, INSTALLED_DEFAULT_PORT } from "./ports";
import { buildLocalServerUrl } from "./serverStatus";

/**
 * Default `bind_address` when omitted (design §2.1). Used for validation and
 * `resolveBindAddress` — not for HTTP client base URLs (those use {@link buildLocalServerUrl}).
 */
export const DEFAULT_BIND_ADDRESS = "127.0.0.1";

export type RuntimeKind = "installed" | "dev";

export type ProfileRole = "server" | "client";

export interface RuntimeConfigFile {
  role: ProfileRole;

  // server-role fields (forbidden on client profiles)
  port?: number;
  data_dir?: string;
  auth_dir?: string;
  open_browser?: boolean;
  bind_address?: string;
  require_cli_api_key?: boolean;
  /** Optional on server; required on client. */
  api_key?: string;

  // client-role fields (forbidden on server profiles)
  api_url?: string;
}

export interface TopLevelConfigFile {
  default_profile?: string;
}

export interface RuntimeConfigOverrides {
  kind?: RuntimeKind;
  profile?: string;
  /** Programmatic override only (e.g. tests); not exposed as a CLI flag. */
  port?: number;
}

let selectedRuntimeKind: RuntimeKind | undefined;
let selectedProfileName: string | undefined;

/** Clears argv-style profile selection; for tests that need a clean resolver state. */
export function resetRuntimeConfigSelectionForTests(): void {
  selectedRuntimeKind = undefined;
  selectedProfileName = undefined;
}

function normalizeProfileName(profile: string | undefined): string | undefined {
  const trimmed = profile?.trim();
  return trimmed ? trimmed : undefined;
}

function resolveHomeDir(): string {
  return process.env.HOME ?? process.env.USERPROFILE ?? process.cwd();
}

function normalizePort(value: unknown): number | undefined {
  if (typeof value === "number" && Number.isInteger(value) && value > 0) {
    return value;
  }

  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    if (Number.isInteger(parsed) && parsed > 0) return parsed;
  }

  return undefined;
}

function normalizeBoolean(value: unknown): boolean | undefined {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true" || normalized === "1") return true;
    if (normalized === "false" || normalized === "0") return false;
  }
  return undefined;
}

function invalidConfigError(
  configPath: string,
  fields: string[],
  message: string,
): CliError {
  return new CliError(message, 2, {
    code: CLI_ERR.invalidConfig,
    configPath,
    fields,
  });
}

export function isLoopbackBindAddress(addr: string): boolean {
  const t = addr.trim().toLowerCase();
  return (
    t === DEFAULT_BIND_ADDRESS || t === "localhost" || t === "::1"
  );
}

function isAbsoluteHttpUrl(value: string): boolean {
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

/**
 * Validates profile `config.json` shape per remote-cli-access design §2.1.
 * Throws CliError(invalidConfig) on failure.
 */
export function validateRuntimeConfigFile(
  raw: Record<string, unknown>,
  configPath: string,
): RuntimeConfigFile {
  const fields: string[] = [];
  const roleRaw = raw.role;
  if (roleRaw !== "server" && roleRaw !== "client") {
    fields.push("role");
  }
  const role = roleRaw as ProfileRole | undefined;
  if (!role) {
    throw invalidConfigError(
      configPath,
      fields,
      `Invalid profile config at ${configPath}: ${fields.join(", ")}`,
    );
  }

  const serverOnly = [
    "port",
    "data_dir",
    "auth_dir",
    "open_browser",
    "bind_address",
    "require_cli_api_key",
  ] as const;
  const clientOnly = ["api_url"] as const;

  if (role === "server") {
    for (const k of clientOnly) {
      if (raw[k] !== undefined) fields.push(k);
    }
    if (normalizePort(raw.port) === undefined) fields.push("port");
    if (typeof raw.data_dir !== "string" || !raw.data_dir.trim()) {
      fields.push("data_dir");
    }
    if (typeof raw.auth_dir !== "string" || !raw.auth_dir.trim()) {
      fields.push("auth_dir");
    }
    if (typeof raw.bind_address === "string" && !raw.bind_address.trim()) {
      fields.push("bind_address");
    }
    if (fields.length) {
      throw invalidConfigError(
        configPath,
        fields,
        `Invalid server profile config at ${configPath}: missing or forbidden fields: ${fields.join(", ")}`,
      );
    }

    const bind =
      typeof raw.bind_address === "string" && raw.bind_address.trim()
        ? raw.bind_address.trim()
        : DEFAULT_BIND_ADDRESS;
    const requireExplicit = normalizeBoolean(raw.require_cli_api_key);
    if (
      !isLoopbackBindAddress(bind) &&
      requireExplicit === false
    ) {
      throw invalidConfigError(
        configPath,
        ["require_cli_api_key", "bind_address"],
        `Invalid server profile config at ${configPath}: non-loopback bind_address requires require_cli_api_key (cannot be false).`,
      );
    }

    if (requireExplicit === true) {
      const key =
        typeof raw.api_key === "string" && raw.api_key.trim()
          ? raw.api_key.trim()
          : undefined;
      if (!key) {
        // Design §2.1 rule 5: warn only; local CLI may still use cli-api-keys.json later.
        console.warn(
          `[taskmanager] Profile ${configPath}: require_cli_api_key is true but api_key is not set. ` +
            `The local CLI on this machine may fail until you set api_key or use cli-api-keys file.`,
        );
      }
    }
  } else {
    // client
    for (const k of serverOnly) {
      if (raw[k] !== undefined) fields.push(k);
    }
    if (raw.api_key !== undefined && typeof raw.api_key !== "string") {
      fields.push("api_key");
    }
    const apiKey =
      typeof raw.api_key === "string" && raw.api_key.trim()
        ? raw.api_key.trim()
        : undefined;
    if (!apiKey) fields.push("api_key");

    const url =
      typeof raw.api_url === "string" && raw.api_url.trim()
        ? raw.api_url.trim()
        : undefined;
    if (!url || !isAbsoluteHttpUrl(url)) {
      fields.push("api_url");
    }

    if (fields.length) {
      throw invalidConfigError(
        configPath,
        fields,
        `Invalid client profile config at ${configPath}: missing or forbidden fields: ${fields.join(", ")}`,
      );
    }
  }

  return raw as unknown as RuntimeConfigFile;
}

export function setRuntimeConfigSelection(selection: {
  kind?: RuntimeKind;
  profile?: string;
}): void {
  if (selection.kind) selectedRuntimeKind = selection.kind;
  if (selection.profile !== undefined) {
    selectedProfileName = normalizeProfileName(selection.profile);
  }
}

// Runtime kind is set explicitly via --dev flag or setRuntimeConfigSelection.
export function resolveRuntimeKind(overrides: RuntimeConfigOverrides = {}): RuntimeKind {
  return (
    overrides.kind ??
    selectedRuntimeKind ??
    "installed"
  );
}

function getTopLevelConfigPath(): string {
  return path.join(getTaskManagerHomeDir(), "config.json");
}

function readTopLevelConfigFile(): TopLevelConfigFile {
  const p = getTopLevelConfigPath();
  if (!existsSync(p)) return {};
  try {
    const raw = readFileSync(p, "utf8").trim();
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
      throw invalidConfigError(
        p,
        ["(top-level config)"],
        `Invalid top-level config at ${p}: expected a JSON object`,
      );
    }
    return parsed as TopLevelConfigFile;
  } catch (e) {
    if (e instanceof CliError) throw e;
    throw invalidConfigError(
      p,
      ["(top-level config)"],
      `Failed to read top-level config at ${p}: ${e instanceof Error ? e.message : String(e)}`,
    );
  }
}

export function resolveDefaultProfileName(): string | undefined {
  const raw = readTopLevelConfigFile().default_profile;
  if (typeof raw !== "string" || !raw.trim()) return undefined;
  return raw.trim();
}

export function writeDefaultProfileName(name: string): void {
  const trimmed = name.trim();
  if (!trimmed) {
    throw invalidConfigError(
      getTopLevelConfigPath(),
      ["default_profile"],
      "default_profile name cannot be empty",
    );
  }
  const home = getTaskManagerHomeDir();
  mkdirSync(home, { recursive: true });
  const p = getTopLevelConfigPath();
  if (existsSync(p)) {
    const existing = readTopLevelConfigFile();
    writeFileSync(
      p,
      `${JSON.stringify({ ...existing, default_profile: trimmed }, null, 2)}\n`,
      "utf8",
    );
  } else {
    writeFileSync(
      p,
      `${JSON.stringify({ default_profile: trimmed }, null, 2)}\n`,
      "utf8",
    );
  }
}

/** Profile directory names under `profiles/` that have a `config.json`. */
export function listProfileNamesWithConfig(): string[] {
  const profilesRoot = path.join(getTaskManagerHomeDir(), "profiles");
  if (!existsSync(profilesRoot)) return [];
  const names: string[] = [];
  try {
    for (const ent of readdirSync(profilesRoot, { withFileTypes: true })) {
      if (!ent.isDirectory()) continue;
      if (existsSync(path.join(profilesRoot, ent.name, "config.json"))) {
        names.push(ent.name);
      }
    }
  } catch {
    return [];
  }
  return names.sort();
}

export function resolveProfileName(
  overrides: RuntimeConfigOverrides = {},
): string {
  const fromOverride = normalizeProfileName(overrides.profile);
  if (fromOverride) return fromOverride;

  if (selectedProfileName) return selectedProfileName;

  const fromPointer = resolveDefaultProfileName();
  if (fromPointer) return fromPointer;

  const withConfig = listProfileNamesWithConfig();
  if (withConfig.length === 1) {
    return withConfig[0]!;
  }
  if (withConfig.length > 1) {
    throw new CliError(
      `Multiple TaskManager profiles exist (${withConfig.join(", ")}) but no default is set. ` +
        `Run \`hirotaskmanager profile use <name>\` or pass --profile.`,
      2,
      {
        code: CLI_ERR.invalidConfig,
        profiles: withConfig,
        hint: "Set default_profile in ~/.taskmanager/config.json or use --profile.",
      },
    );
  }

  return "default";
}

export function getTaskManagerHomeDir(): string {
  return path.join(resolveHomeDir(), ".taskmanager");
}

/** True if any `~/.taskmanager/profiles/<name>/config.json` exists (any named profile). */
export function hasAnyProfileConfigOnDisk(): boolean {
  return listProfileNamesWithConfig().length > 0;
}

export function getProfileRootDir(overrides: RuntimeConfigOverrides = {}): string {
  return path.join(getTaskManagerHomeDir(), "profiles", resolveProfileName(overrides));
}

export function ensureProfileRootDir(overrides: RuntimeConfigOverrides = {}): string {
  const profileRootDir = getProfileRootDir(overrides);
  mkdirSync(profileRootDir, { recursive: true });
  return profileRootDir;
}

export function ensureRuntimeDirectories(
  overrides: RuntimeConfigOverrides = {},
): {
  profileRootDir: string;
  dataDir: string;
  authDir: string;
} {
  const profileRootDir = ensureProfileRootDir(overrides);
  const dataDir = resolveDataDir(overrides);
  const authDir = resolveAuthDir(overrides);

  mkdirSync(dataDir, { recursive: true });
  mkdirSync(authDir, { recursive: true });

  return {
    profileRootDir,
    dataDir,
    authDir,
  };
}

export function getProfileConfigFilePath(overrides: RuntimeConfigOverrides = {}): string {
  return path.join(getProfileRootDir(overrides), "config.json");
}

export function hasProfileConfigFile(overrides: RuntimeConfigOverrides = {}): boolean {
  return existsSync(getProfileConfigFilePath(overrides));
}

function parseProfileConfigJson(
  raw: string,
  configPath: string,
): Record<string, unknown> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    throw invalidConfigError(
      configPath,
      ["(invalid JSON)"],
      `Invalid JSON in profile config at ${configPath}: ${e instanceof Error ? e.message : String(e)}`,
    );
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw invalidConfigError(
      configPath,
      ["(invalid shape)"],
      `Profile config at ${configPath} must be a JSON object`,
    );
  }
  return parsed as Record<string, unknown>;
}

/**
 * Reads and validates the active profile's `config.json`.
 * Returns `undefined` when the file is missing (caller may treat as bootstrap / no profile yet).
 * Throws {@link CliError} with `CLI_ERR.invalidConfig` when the file exists but is invalid.
 */
export function readProfileConfig(
  overrides: RuntimeConfigOverrides = {},
): RuntimeConfigFile | undefined {
  const configFilePath = getProfileConfigFilePath(overrides);
  if (!existsSync(configFilePath)) return undefined;

  let raw: string;
  try {
    raw = readFileSync(configFilePath, "utf8").trim();
  } catch (e) {
    throw invalidConfigError(
      configFilePath,
      ["(read error)"],
      `Failed to read profile config at ${configFilePath}: ${e instanceof Error ? e.message : String(e)}`,
    );
  }
  if (!raw) {
    throw invalidConfigError(
      configFilePath,
      ["(empty file)"],
      `Profile config at ${configFilePath} is empty`,
    );
  }
  const obj = parseProfileConfigJson(raw, configFilePath);
  return validateRuntimeConfigFile(obj, configFilePath);
}

function requireReadProfileConfig(
  overrides: RuntimeConfigOverrides,
): RuntimeConfigFile {
  const c = readProfileConfig(overrides);
  if (!c) {
    const p = getProfileConfigFilePath(overrides);
    throw invalidConfigError(
      p,
      ["(missing file)"],
      `Profile config is missing at ${p}. Create it with hirotaskmanager setup or add role and required fields.`,
    );
  }
  return c;
}

function assertRoleServer(
  config: RuntimeConfigFile,
  configPath: string,
): void {
  if (config.role !== "server") {
    throw invalidConfigError(
      configPath,
      ["role"],
      `Expected server profile at ${configPath}; use a server profile for this operation.`,
    );
  }
}

export function resolveProfileRole(
  overrides: RuntimeConfigOverrides = {},
): ProfileRole {
  return requireReadProfileConfig(overrides).role;
}

export function resolveBindAddress(
  overrides: RuntimeConfigOverrides = {},
): string {
  const config = requireReadProfileConfig(overrides);
  const configPath = getProfileConfigFilePath(overrides);
  assertRoleServer(config, configPath);
  const raw = config.bind_address?.trim();
  return raw || DEFAULT_BIND_ADDRESS;
}

export function resolveRequireCliApiKey(
  overrides: RuntimeConfigOverrides = {},
): boolean {
  const config = requireReadProfileConfig(overrides);
  const configPath = getProfileConfigFilePath(overrides);
  assertRoleServer(config, configPath);
  if (config.require_cli_api_key !== undefined) {
    return config.require_cli_api_key;
  }
  // Inline bind default so we do not recurse through resolveBindAddress + requireReadProfileConfig again.
  const bind = config.bind_address?.trim() || DEFAULT_BIND_ADDRESS;
  return !isLoopbackBindAddress(bind);
}

/**
 * API base URL for the active profile: loopback + port for server profiles; `api_url` for clients.
 */
export function resolveApiUrl(overrides: RuntimeConfigOverrides = {}): string {
  const config = readProfileConfig(overrides);
  if (!config) {
    const port =
      normalizePort(overrides.port) ?? getDefaultPort(overrides);
    return buildLocalServerUrl(port);
  }
  if (config.role === "client") {
    return config.api_url!.replace(/\/+$/, "");
  }
  const port = resolvePort(overrides);
  return buildLocalServerUrl(port);
}

export function writeProfileConfig(
  config: RuntimeConfigFile,
  overrides: RuntimeConfigOverrides = {},
): string {
  const configFilePath = path.join(ensureProfileRootDir(overrides), "config.json");
  validateRuntimeConfigFile(
    { ...(config as unknown as Record<string, unknown>) },
    configFilePath,
  );
  writeFileSync(configFilePath, `${JSON.stringify(config, null, 2)}\n`, "utf8");
  return configFilePath;
}

export function getDefaultPort(overrides: RuntimeConfigOverrides = {}): number {
  return resolveRuntimeKind(overrides) === "dev"
    ? DEV_DEFAULT_PORT
    : INSTALLED_DEFAULT_PORT;
}

// All profiles (including dev) use the profile-based data dir under
// ~/.taskmanager/profiles/<name>/data unless `data_dir` in config.json overrides.
export function getDefaultDataDir(overrides: RuntimeConfigOverrides = {}): string {
  return path.join(getProfileRootDir(overrides), "data");
}

export function getDefaultAuthDir(overrides: RuntimeConfigOverrides = {}): string {
  return path.join(getProfileRootDir(overrides), "auth");
}

export function getServerPidFilePath(overrides: RuntimeConfigOverrides = {}): string {
  return path.join(getProfileRootDir(overrides), "server.pid.json");
}

export function resolvePort(overrides: RuntimeConfigOverrides = {}): number {
  const config = readProfileConfig(overrides);
  if (!config) {
    return (
      normalizePort(overrides.port) ?? getDefaultPort(overrides)
    );
  }
  const configPath = getProfileConfigFilePath(overrides);
  assertRoleServer(config, configPath);
  return (
    normalizePort(overrides.port) ??
    normalizePort(config.port) ??
    getDefaultPort(overrides)
  );
}

export function resolveDataDir(overrides: RuntimeConfigOverrides = {}): string {
  const config = readProfileConfig(overrides);
  if (!config) {
    return path.resolve(getDefaultDataDir(overrides));
  }
  const configPath = getProfileConfigFilePath(overrides);
  assertRoleServer(config, configPath);
  return path.resolve(
    config.data_dir ?? getDefaultDataDir(overrides),
  );
}

export function resolveAuthDir(overrides: RuntimeConfigOverrides = {}): string {
  const config = readProfileConfig(overrides);
  if (!config) {
    return path.resolve(getDefaultAuthDir(overrides));
  }
  const configPath = getProfileConfigFilePath(overrides);
  assertRoleServer(config, configPath);
  return path.resolve(
    config.auth_dir ?? getDefaultAuthDir(overrides),
  );
}

export function resolveOpenBrowser(overrides: RuntimeConfigOverrides = {}): boolean {
  const config = readProfileConfig(overrides);
  if (!config) {
    return true;
  }
  const configPath = getProfileConfigFilePath(overrides);
  assertRoleServer(config, configPath);
  return (
    normalizeBoolean(config.open_browser) ??
    true
  );
}

export function resolveApiKey(overrides: RuntimeConfigOverrides = {}): string | undefined {
  const config = readProfileConfig(overrides);
  if (!config) return undefined;
  if (config.api_key?.trim()) return config.api_key.trim();
  return undefined;
}

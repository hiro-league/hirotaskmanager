import { cn } from "@/lib/utils";

type CursorMarkIconProps = {
  className?: string;
  /** Facet cutout: match modal buttons (`background`) vs popover menus (`popover`). */
  innerSurface?: "background" | "popover";
};

/**
 * Cursor product cube mark only (horizontal wordmark cropped). Derived from the
 * Wikimedia Commons Cursor logo (public domain): https://commons.wikimedia.org/wiki/File:Cursor_logo.svg
 * — paths trimmed to the left lockup for small UI slots.
 */
export function CursorMarkIcon({
  className,
  innerSurface = "background",
}: CursorMarkIconProps) {
  const innerFill =
    innerSurface === "popover" ? "var(--popover)" : "var(--background)";
  return (
    <svg
      className={cn("shrink-0", className)}
      viewBox="0 0 125 145"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
    >
      <path
        fill="currentColor"
        d="M 60.66 0.00 L 64.42 0.00 C 82.67 10.62 100.99 21.12 119.25 31.72 C 121.24 33.01 123.54 34.18 124.72 36.34 C 125.34 39.17 125.06 42.10 125.11 44.98 C 125.07 63.63 125.08 82.28 125.11 100.93 C 125.07 102.84 125.14 104.79 124.73 106.68 C 123.53 108.54 121.50 109.62 119.68 110.77 C 104.03 119.72 88.45 128.80 72.85 137.83 C 69.53 139.68 66.36 141.91 62.74 143.17 C 60.51 142.85 58.57 141.57 56.62 140.54 C 40.81 131.22 24.82 122.22 9.00 112.92 C 5.85 111.16 2.79 109.23 0.00 106.93 L 0.00 36.10 C 3.83 32.32 8.81 30.12 13.34 27.33 C 29.10 18.19 44.82 8.98 60.66 0.00 M 5.62 38.04 C 8.28 40.64 11.88 41.83 14.96 43.80 C 30.60 53.06 46.50 61.89 62.05 71.30 C 62.86 75.82 62.50 80.43 62.55 85.00 C 62.57 100.64 62.51 116.29 62.54 131.93 C 62.54 133.69 62.72 135.44 63.01 137.17 C 64.18 135.60 65.29 133.98 66.24 132.27 C 83.07 103.08 99.93 73.92 116.65 44.67 C 117.89 42.62 118.84 40.42 119.57 38.14 C 113.41 37.65 107.23 37.91 101.06 37.87 C 73.71 37.85 46.35 37.85 18.99 37.87 C 14.54 38.02 10.07 37.53 5.62 38.04 Z"
      />
      <path
        fill={innerFill}
        d="M 5.62 38.04 C 10.07 37.53 14.54 38.02 18.99 37.87 C 46.35 37.85 73.71 37.85 101.06 37.87 C 107.23 37.91 113.41 37.65 119.57 38.14 C 118.84 40.42 117.89 42.62 116.65 44.67 C 99.93 73.92 83.07 103.08 66.24 132.27 C 65.29 133.98 64.18 135.60 63.01 137.17 C 62.72 135.44 62.54 133.69 62.54 131.93 C 62.51 116.29 62.57 100.64 62.55 85.00 C 62.50 80.43 62.86 75.82 62.05 71.30 C 46.50 61.89 30.60 53.06 14.96 43.80 C 11.88 41.83 8.28 40.64 5.62 38.04 Z"
      />
    </svg>
  );
}

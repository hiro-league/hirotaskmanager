import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useState,
  useRef,
  type RefCallback,
} from "react";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { MoreVertical } from "lucide-react";
import { useDeleteList, usePatchList } from "@/api/mutations";
import { EmojiPickerMenuButton } from "@/components/emoji/EmojiPickerMenuButton";
import { ConfirmDialog } from "@/components/board/shortcuts/ConfirmDialog";
import { useBoardKeyboardNavOptional } from "@/components/board/shortcuts/BoardKeyboardNavContext";
import { useShortcutOverlay } from "@/components/board/shortcuts/ShortcutScopeContext";
import { cn } from "@/lib/utils";
import { listDisplayName, type List } from "../../../shared/models";

interface ListHeaderProps {
  boardId: number;
  list: List;
  /** Attach the list drag handle for board column sorting. */
  dragHandleRef?: RefCallback<HTMLElement>;
}

function ListEmojiPicker({
  emoji,
  busy,
  onPickEmoji,
  onValidationError,
}: {
  emoji: string | null | undefined;
  busy: boolean;
  onPickEmoji: (next: string | null) => void;
  onValidationError: (message: string) => void;
}) {
  return (
    <div
      className={cn(
        "shrink-0 transition-opacity duration-150",
        "opacity-0 group-hover/list-header:opacity-100 focus-within:opacity-100",
        "[&_button[data-state=open]]:opacity-100",
      )}
    >
      {/* lazyMountDropdown: board perf plan #6 — skip Radix Portal/Presence per list until emoji is used */}
      <EmojiPickerMenuButton
        emoji={emoji}
        disabled={busy}
        compact
        lazyMountDropdown
        alwaysShowPlaceholder
        placeholderIcon={
          <span className="text-[0.875rem] leading-none" aria-hidden>
            ❔
          </span>
        }
        onValidationError={onValidationError}
        chooseAriaLabel="Choose list emoji"
        selectedAriaLabel={(e) => `Change list emoji (${e})`}
        onPick={onPickEmoji}
      />
    </div>
  );
}

export function ListHeader({
  boardId,
  list,
  dragHandleRef,
}: ListHeaderProps) {
  const patchList = usePatchList();
  const deleteList = useDeleteList();
  const boardNav = useBoardKeyboardNavOptional();
  const [editing, setEditing] = useState(false);
  const [editValue, setEditValue] = useState(list.name);
  const [menuOpen, setMenuOpen] = useState(false);
  const [listDeleteConfirmOpen, setListDeleteConfirmOpen] = useState(false);
  const [emojiFieldError, setEmojiFieldError] = useState<string | null>(null);
  /** Measures the truncated list name span so we only show a native tooltip when text overflows. */
  const listNameSpanRef = useRef<HTMLSpanElement | null>(null);
  const [listNameTruncated, setListNameTruncated] = useState(false);

  const boardDrag = dragHandleRef != null;
  const busy = patchList.isPending;

  const baseName = list.name.trim() || String(list.listId);
  const emojiChar = list.emoji?.trim() || null;

  const startRename = useCallback(() => {
    // Keep the list current when rename is entered so canceling leaves the
    // user's last-touched list selected.
    boardNav?.selectList(list.listId);
    setEditing(true);
    setEditValue(list.name);
  }, [boardNav, list.listId, list.name]);

  // F2 on a keyboard-selected list calls the same entry point as click / ⋮ Rename.
  useEffect(() => {
    if (!boardNav) return;
    return boardNav.registerListRename(list.listId, startRename);
  }, [boardNav, list.listId, startRename]);

  const cancelRename = useCallback(() => {
    setEditing(false);
    setEditValue(list.name);
  }, [list.name]);

  const commitRename = useCallback(async () => {
    const trimmed = editValue.trim();
    setEditing(false);
    if (!trimmed || trimmed === list.name) {
      setEditValue(list.name);
      return;
    }
    try {
      await patchList.mutateAsync({
        boardId,
        listId: list.listId,
        patch: { name: trimmed },
      });
    } catch {
      setEditValue(list.name);
    }
  }, [boardId, editValue, list.listId, list.name, patchList]);

  // Phase 4: Esc for list menu goes through scoped shortcut stack (board shortcuts stay suppressed).
  useShortcutOverlay(
    menuOpen,
    "list-header-menu",
    useCallback((e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      e.preventDefault();
      setMenuOpen(false);
    }, []),
  );

  const handleDelete = useCallback(() => {
    setMenuOpen(false);
    setListDeleteConfirmOpen(true);
  }, []);

  const confirmListDelete = useCallback(() => {
    deleteList.mutate({ boardId, listId: list.listId });
    setListDeleteConfirmOpen(false);
  }, [boardId, deleteList, list.listId]);

  const displayName = listDisplayName(list);

  useLayoutEffect(() => {
    if (editing) {
      setListNameTruncated(false);
      return;
    }
    const el = listNameSpanRef.current;
    if (!el) return;
    const check = () => {
      setListNameTruncated(el.scrollWidth > el.clientWidth + 1);
    };
    check();
    const ro = new ResizeObserver(check);
    ro.observe(el);
    return () => ro.disconnect();
  }, [editing, baseName, emojiChar, boardDrag]);

  const pickListEmoji = useCallback(
    (next: string | null) => {
      setEmojiFieldError(null);
      void patchList.mutateAsync({
        boardId,
        listId: list.listId,
        patch: { emoji: next },
      });
    },
    [boardId, list.listId, patchList],
  );

  const titleLine = (
    <>
      {emojiChar ? (
        <span className="shrink-0 text-[0.9375rem] leading-tight" aria-hidden>
          {emojiChar}
        </span>
      ) : null}
      <span
        ref={listNameSpanRef}
        className="min-w-0 truncate"
        title={listNameTruncated ? displayName : undefined}
      >
        {baseName}
      </span>
    </>
  );

  return (
    <>
    <div
      className={cn(
        "group/list-header relative flex w-full min-h-10 items-center justify-end gap-1 border-border bg-muted/40 px-2 py-1.5",
        boardDrag ? "border-b border-border/80" : "rounded-t-md border border-b-0",
      )}
      onPointerDown={() => {
        // Any direct interaction with the header should make this list current.
        boardNav?.selectList(list.listId);
      }}
    >
      {emojiFieldError ? (
        <p className="absolute left-2 top-full z-20 mt-0.5 max-w-[min(100%,12rem)] text-[10px] text-destructive">
          {emojiFieldError}
        </p>
      ) : null}
      {editing ? (
        <div className="flex min-w-0 flex-1 items-center gap-1 pr-8">
          <ListEmojiPicker
            emoji={list.emoji}
            busy={busy}
            onValidationError={setEmojiFieldError}
            onPickEmoji={pickListEmoji}
          />
          {emojiChar ? (
            <span className="shrink-0 text-lg leading-none" aria-hidden>
              {emojiChar}
            </span>
          ) : null}
          <input
            autoComplete="off"
            spellCheck={false}
            autoFocus
            className="min-w-0 flex-1 rounded border border-input bg-background px-2 py-1 text-sm text-foreground select-text"
            value={editValue}
            disabled={busy}
            onChange={(e) => setEditValue(e.target.value)}
            onPointerDown={(e) => e.stopPropagation()}
            onBlur={() => void commitRename()}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.currentTarget.blur();
              }
              if (e.key === "Escape") {
                cancelRename();
              }
            }}
          />
        </div>
      ) : boardDrag ? (
        <>
          <div className="pointer-events-none min-w-0 flex-1" aria-hidden />
          <div
            ref={dragHandleRef}
            className="absolute inset-y-0 left-2 right-10 z-[1] flex cursor-grab touch-none items-center justify-center gap-1 active:cursor-grabbing"
            // List-column drag now waits for pointer movement, so a plain click
            // on the title can reliably enter rename mode again.
            onClick={() => {
              if (!editing) startRename();
            }}
          >
            <div
              className="pointer-events-auto flex shrink-0 items-center"
              onClick={(e) => e.stopPropagation()}
              onPointerDown={(e) => e.stopPropagation()}
            >
              <ListEmojiPicker
                emoji={list.emoji}
                busy={busy}
                onValidationError={setEmojiFieldError}
                onPickEmoji={pickListEmoji}
              />
            </div>
            <span className="flex min-w-0 flex-1 items-center justify-center gap-1 truncate text-center text-[0.9375rem] font-bold leading-tight text-foreground">
              {titleLine}
            </span>
          </div>
        </>
      ) : (
        <div className="flex min-w-0 flex-1 items-center justify-center gap-1">
          <ListEmojiPicker
            emoji={list.emoji}
            busy={busy}
            onValidationError={setEmojiFieldError}
            onPickEmoji={pickListEmoji}
          />
          <button
            type="button"
            className="flex min-w-0 flex-1 items-center justify-center gap-1 truncate rounded px-1 py-0.5 text-center text-[0.9375rem] font-bold leading-tight text-foreground hover:bg-muted/80"
            onClick={startRename}
          >
            {titleLine}
          </button>
        </div>
      )}
      {!editing && (
        <DropdownMenu.Root
          modal={false}
          open={menuOpen}
          onOpenChange={setMenuOpen}
        >
          <DropdownMenu.Trigger asChild>
            <button
              type="button"
              className="rounded p-1 text-muted-foreground opacity-0 hover:bg-muted/80 group-hover/list-header:opacity-100 data-[state=open]:opacity-100"
              aria-label={`Actions for ${displayName}`}
              onPointerDown={(e) => e.stopPropagation()}
            >
              <MoreVertical className="size-4" aria-hidden />
            </button>
          </DropdownMenu.Trigger>
          <DropdownMenu.Portal>
            <DropdownMenu.Content
              side="right"
              align="start"
              sideOffset={4}
              collisionPadding={8}
              className="z-[100] min-w-[9.5rem] max-h-[var(--radix-dropdown-menu-content-available-height)] overflow-y-auto overscroll-y-contain rounded-md border border-border bg-popover p-1 text-sm text-popover-foreground shadow-md"
            >
              <DropdownMenu.Item
                className="flex cursor-default rounded px-2 py-1.5 outline-none hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                onSelect={() => {
                  startRename();
                }}
              >
                Rename
              </DropdownMenu.Item>
              <DropdownMenu.Item
                className="flex cursor-default rounded px-2 py-1.5 text-destructive outline-none hover:bg-destructive/10 focus:bg-destructive/10"
                onSelect={() => {
                  handleDelete();
                }}
              >
                Move to Trash
              </DropdownMenu.Item>
            </DropdownMenu.Content>
          </DropdownMenu.Portal>
        </DropdownMenu.Root>
      )}
    </div>

      <ConfirmDialog
        open={listDeleteConfirmOpen}
        scope="list-delete-confirmation"
        title="Move this list to Trash?"
        message={`Move list “${displayName}” to Trash? Its tasks move with it; you can restore from Trash or delete permanently there.`}
        confirmLabel="Move to Trash"
        cancelLabel="Cancel"
        variant="destructive"
        onCancel={() => setListDeleteConfirmOpen(false)}
        onConfirm={confirmListDelete}
      />
  </>
  );
}
